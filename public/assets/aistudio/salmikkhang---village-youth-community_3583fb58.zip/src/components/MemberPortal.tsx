import React, { useState } from 'react';
import { useCommunity } from '../context/CommunityContext';
import { Member, DiscussionPost } from '../types';
import {
  User,
  Shield,
  MapPin,
  Droplet,
  Phone,
  Mail,
  Calendar,
  MessageSquare,
  ThumbsUp,
  Search,
  Users,
  Award,
  Send,
  Edit3,
  Check,
  DollarSign,
  Sparkles,
  LogOut,
  FileText,
  Bell,
  Download,
  ExternalLink,
  CheckCheck,
  X
} from 'lucide-react';

export const MemberPortal: React.FC = () => {
  const {
    t,
    currentMember,
    members,
    events,
    news,
    notifications,
    markNotificationAsRead,
    clearAllNotifications,
    discussions,
    funds,
    settings,
    setCurrentView,
    logoutMember,
    openModal,
    addDiscussionPost,
    likeDiscussionPost,
    addDiscussionReply,
    updateMember,
    toggleEventRsvp,
    loginAsMember
  } = useCommunity();

  // Active tab inside member portal
  const [activeTab, setActiveTab] = useState<'wall' | 'notices' | 'directory' | 'events' | 'fund'>('wall');

  // Notification center popup state
  const [notificationOpen, setNotificationOpen] = useState(false);

  // New post state
  const [newPostText, setNewPostText] = useState('');
  const [newPostCategory, setNewPostCategory] = useState<DiscussionPost['category']>('General');

  // Reply inputs state
  const [replyInputs, setReplyInputs] = useState<{ [key: string]: string }>({});

  // Directory search & blood group filter
  const [directorySearch, setDirectorySearch] = useState('');
  const [bloodFilter, setBloodFilter] = useState('All');
  const [villageFilter, setVillageFilter] = useState('All');

  // Notices search & audience filter
  const [noticeSearch, setNoticeSearch] = useState('');
  const [noticeAudienceFilter, setNoticeAudienceFilter] = useState<'All' | 'members_only' | 'public'>('All');

  // Edit profile state
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editPhone, setEditPhone] = useState(currentMember?.phone || '');
  const [editVillage, setEditVillage] = useState(currentMember?.village || '');
  const [editBlood, setEditBlood] = useState(currentMember?.bloodGroup || '');
  const [editBio, setEditBio] = useState(currentMember?.bio || '');

  const [loginInputName, setLoginInputName] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  const unreadNotifsCount = notifications.filter(n => !n.read).length;

  // 1. MEMBER LOGIN GATEWAY (If not logged in as Member)
  if (!currentMember) {
    return (
      <div className="max-w-xl mx-auto py-16 px-4 transition-colors">
        <div className="bg-white dark:bg-slate-900 p-8 sm:p-10 rounded-3xl border border-emerald-100 dark:border-slate-800 shadow-xl space-y-6">
          <div className="text-center space-y-2">
            <div className="w-16 h-16 rounded-2xl bg-emerald-800 dark:bg-emerald-700 text-white flex items-center justify-center mx-auto shadow-md">
              <span className="text-2xl">🌿</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-slate-100 tracking-tight">
              {t('Member Portal Login', 'সদস্য পোর্টালে লগইন')}
            </h2>
            <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm max-w-sm mx-auto">
              {t(
                'Enter your registered member email/phone and password to enter the youth portal.',
                'সদস্য পোর্টালে প্রবেশের জন্য আপনার নিবন্ধিত ইমেইল বা ফোন এবং পাসওয়ার্ড দিন।'
              )}
            </p>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (loginInputName.trim()) {
                loginAsMember(loginInputName.trim(), loginPassword.trim());
              }
            }}
            className="space-y-4"
          >
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
                {t('Member Name / Email / Phone *', 'সদস্যের নাম / ইমেইল / ফোন *')}
              </label>
              <input
                type="text"
                required
                value={loginInputName}
                onChange={(e) => setLoginInputName(e.target.value)}
                placeholder={t('e.g. blancho.261071027@smuct.ac.bd or 01712-889900', 'যেমন: blancho.261071027@smuct.ac.bd')}
                className="w-full px-4 py-3 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
                {t('Member Password *', 'পাসওয়ার্ড *')}
              </label>
              <input
                type="password"
                required
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                placeholder="password123"
                className="w-full px-4 py-3 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-transparent"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm rounded-xl shadow-md transition-transform hover:-translate-y-0.5 active:translate-y-0"
            >
              {t('Login to Member Portal →', 'সদস্য পোর্টালে প্রবেশ করুন →')}
            </button>
          </form>

          {/* Quick 1-click Demo Profiles */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
            <span className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block">
              {t('Quick 1-Click Member Login (Demo):', 'এক ক্লিকে ডেমো লগইন:')}
            </span>
            <div className="space-y-2">
              {members.slice(0, 3).map((m) => (
                <button
                  key={m.id}
                  onClick={() => loginAsMember(m.email, m.password || 'password123')}
                  className="w-full p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/70 hover:bg-emerald-50 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-700 flex items-center justify-between text-xs text-left transition-colors group"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold flex items-center justify-center text-xs">
                      {m.name[0]}
                    </div>
                    <div>
                      <div className="font-bold text-slate-900 dark:text-slate-100 group-hover:text-emerald-900 dark:group-hover:text-emerald-300">{m.name}</div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">{m.role} · {m.village} · Pass: {m.password || 'password123'}</div>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold text-emerald-700 dark:text-emerald-400 group-hover:translate-x-0.5 transition-transform">
                    {t('Login →', 'লগইন →')}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500 dark:text-slate-400">
            <button
              onClick={() => openModal('join')}
              className="text-emerald-700 dark:text-emerald-400 hover:text-emerald-900 font-bold underline"
            >
              {t('Want to become a member? Submit application to Admin →', 'সদস্য হতে চান? অ্যাডমিনের কাছে আবেদন জমা দিন →')}
            </button>
            <button
              onClick={() => setCurrentView('website')}
              className="text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 font-medium"
            >
              ← {t('Back to Public Website', 'ওয়েবসাইটে ফিরে যান')}
            </button>
          </div>
        </div>
      </div>
    );
  }

  const handlePostSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostText.trim()) return;
    addDiscussionPost(newPostText.trim(), newPostCategory);
    setNewPostText('');
  };

  const handleReplySubmit = (postId: string) => {
    const text = replyInputs[postId]?.trim();
    if (!text) return;
    addDiscussionReply(postId, text);
    setReplyInputs(prev => ({ ...prev, [postId]: '' }));
  };

  const handleSaveProfile = () => {
    updateMember(currentMember.id, {
      phone: editPhone,
      village: editVillage,
      bloodGroup: editBlood,
      bio: editBio
    });
    setIsEditingProfile(false);
  };

  // Filter directory
  const filteredMembers = members.filter(m => {
    const matchesSearch =
      m.name.toLowerCase().includes(directorySearch.toLowerCase()) ||
      m.village.toLowerCase().includes(directorySearch.toLowerCase()) ||
      m.skills.some(s => s.toLowerCase().includes(directorySearch.toLowerCase()));

    const matchesBlood = bloodFilter === 'All' || m.bloodGroup === bloodFilter;
    const matchesVillage = villageFilter === 'All' || m.village === villageFilter;

    return matchesSearch && matchesBlood && matchesVillage;
  });

  // Filter notices (search + audience)
  const filteredNotices = news.filter(n => {
    const matchesSearch =
      n.title.toLowerCase().includes(noticeSearch.toLowerCase()) ||
      n.content.toLowerCase().includes(noticeSearch.toLowerCase()) ||
      n.category.toLowerCase().includes(noticeSearch.toLowerCase());

    const matchesAudience =
      noticeAudienceFilter === 'All' ||
      (noticeAudienceFilter === 'members_only' && n.visibility === 'members_only') ||
      (noticeAudienceFilter === 'public' && n.visibility !== 'members_only');

    return matchesSearch && matchesAudience;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 transition-colors">
      
      {/* 1. Top Bar with Welcome & Member Notification Center */}
      <div className="grid lg:grid-cols-12 gap-8 items-start">
        
        {/* Welcome message & member info */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider">
              {t('SALMIKKHANG MEMBER PORTAL', 'সালমিকখাং সদস্য প্যানেল')}
            </span>
            <div className="flex items-center gap-3">
              {/* Notification Bell Button */}
              <button
                onClick={() => setNotificationOpen(!notificationOpen)}
                className="relative p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-slate-700 transition-colors"
                title="Member Notifications & PDF Circulars"
              >
                <Bell className="w-4 h-4 text-emerald-700 dark:text-emerald-400" />
                {unreadNotifsCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-rose-600 text-white text-[10px] font-black rounded-full flex items-center justify-center animate-pulse">
                    {unreadNotifsCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => setCurrentView('website')}
                className="text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-emerald-700 dark:hover:text-emerald-300 underline"
              >
                ← {t('Public Website', 'মূল ওয়েবসাইট')}
              </button>
              <button
                onClick={logoutMember}
                className="flex items-center gap-1 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:text-rose-800 ml-2"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>{t('Logout', 'লগআউট')}</span>
              </button>
            </div>
          </div>

          <h1 className="text-3xl font-extrabold text-slate-900 dark:text-slate-100 tracking-tight">
            {t('Welcome back,', 'স্বাগতম,')} <span className="text-emerald-700 dark:text-emerald-400">{currentMember.name}</span>
          </h1>

          <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
            {t(
              'Stay connected with Gaira & Jolchotro youth activities, read official PDF circulars, RSVP for drives, and engage in discussions.',
              'গাইরা ও জলছত্রের তরুণদের সাথে যুক্ত থাকুন, অফিসিয়াল PDF পরিপত্র পড়ুন, অনুষ্ঠানে অংশ নিন এবং মতবিনিময়ে যুক্ত থাকুন।'
            )}
          </p>

          {/* Quick Member Switcher Bar for demo convenience */}
          <div className="p-3 bg-emerald-50/70 dark:bg-emerald-950/40 rounded-2xl border border-emerald-100 dark:border-emerald-900 flex flex-wrap items-center gap-2 text-xs">
            <span className="font-bold text-emerald-900 dark:text-emerald-300">{t('Switch demo profile:', 'প্রোফাইল পরিবর্তন:')}</span>
            {members.slice(0, 4).map(m => (
              <button
                key={m.id}
                onClick={() => loginAsMember(m.email, m.password || 'password123')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  m.id === currentMember.id
                    ? 'bg-emerald-700 text-white font-bold'
                    : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-emerald-100 dark:hover:bg-slate-700 border border-emerald-200 dark:border-slate-700'
                }`}
              >
                {m.name.split(' ')[0]} ({m.role.split(' ')[0]})
              </button>
            ))}
          </div>
        </div>

        {/* Digital Membership ID Card */}
        <div className="lg:col-span-5">
          <div className="bg-gradient-to-br from-emerald-800 via-emerald-900 to-teal-950 text-white rounded-3xl p-6 shadow-xl border border-emerald-700/50 relative overflow-hidden">
            <div className="absolute right-[-20px] bottom-[-20px] opacity-10 pointer-events-none">
              <Shield className="w-56 h-56" />
            </div>

            <div className="flex items-center justify-between pb-4 border-b border-emerald-700/60">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-white/20 flex items-center justify-center font-bold text-xs">
                  🌿
                </div>
                <div className="font-extrabold text-xs tracking-wider uppercase text-emerald-200">
                  Salmikkhang Youth Council
                </div>
              </div>
              <span className="text-[10px] font-mono uppercase bg-emerald-700/80 px-2 py-0.5 rounded text-emerald-100">
                {currentMember.memberNo}
              </span>
            </div>

            <div className="pt-4 flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center text-2xl font-black shrink-0 overflow-hidden">
                {currentMember.avatar ? (
                  <img src={currentMember.avatar} alt={currentMember.name} className="w-full h-full object-cover" />
                ) : (
                  currentMember.name[0]
                )}
              </div>

              <div className="space-y-0.5">
                <h3 className="text-lg font-black tracking-tight">{currentMember.name}</h3>
                <div className="text-xs text-emerald-300 font-semibold">{currentMember.role}</div>
                <div className="text-[11px] text-emerald-200/80 flex items-center gap-2">
                  <span>📍 {currentMember.village}, Madhupur</span>
                  <span>🩸 {currentMember.bloodGroup}</span>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-emerald-700/60 flex items-center justify-between text-[11px] text-emerald-200/90">
              <span>{t('Status: Verified Active', 'অবস্থা: সক্রিয় সদস্য')}</span>
              <button
                onClick={() => setIsEditingProfile(!isEditingProfile)}
                className="text-xs font-bold text-white hover:underline flex items-center gap-1"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>{isEditingProfile ? t('Close Editor', 'বন্ধ করুন') : t('Edit My Details', 'তথ্য এডিট')}</span>
              </button>
            </div>
          </div>
        </div>

      </div>

      {/* NOTIFICATION POPUP MODAL */}
      {notificationOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Bell className="w-5 h-5 text-emerald-700 dark:text-emerald-400" />
                <h3 className="font-extrabold text-base text-slate-900 dark:text-slate-100">
                  {t('Member Notifications & PDF Circulars', 'সদস্য নোটিফিকেশন ও পরিপত্র')}
                </h3>
              </div>
              <button
                onClick={() => setNotificationOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {notifications.length === 0 ? (
              <div className="py-8 text-center text-slate-400 text-xs">
                {t('No notifications yet.', 'কোনো নতুন নোটিফিকেশন নেই।')}
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex justify-end gap-2 text-[11px]">
                  <button
                    onClick={clearAllNotifications}
                    className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                  >
                    {t('Clear all', 'সব মুছুন')}
                  </button>
                </div>

                {notifications.map(n => (
                  <div
                    key={n.id}
                    className={`p-4 rounded-2xl border transition-all space-y-2 text-xs ${
                      !n.read
                        ? 'bg-emerald-50/60 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800'
                        : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 opacity-80'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="space-y-0.5">
                        <div className="font-bold text-sm text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                          {!n.read && <span className="w-2 h-2 rounded-full bg-emerald-600 shrink-0" />}
                          <span>{t(n.title, n.titleBn)}</span>
                        </div>
                        <div className="text-[10px] text-slate-400">{n.date} · {n.type.toUpperCase()}</div>
                      </div>
                      {!n.read && (
                        <button
                          onClick={() => markNotificationAsRead(n.id)}
                          className="text-[10px] font-bold text-emerald-700 dark:text-emerald-400 hover:underline shrink-0"
                        >
                          {t('Mark as read', 'পঠিত')}
                        </button>
                      )}
                    </div>

                    <p className="text-slate-600 dark:text-slate-300 text-xs">{t(n.message, n.messageBn)}</p>

                    {/* PDF Attachment in notification */}
                    {n.pdfAttachment && (
                      <div className="p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-rose-200 dark:border-rose-900 flex items-center justify-between gap-3 mt-2">
                        <div className="flex items-center gap-2 truncate">
                          <FileText className="w-4 h-4 text-rose-600 shrink-0" />
                          <span className="font-bold text-xs text-slate-900 dark:text-slate-100 truncate">
                            {n.pdfAttachment.fileName}
                          </span>
                        </div>
                        <a
                          href={n.pdfAttachment.dataUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white font-bold text-[11px] rounded-lg shrink-0 flex items-center gap-1"
                        >
                          <ExternalLink className="w-3 h-3" />
                          <span>{t('Open PDF', 'PDF খুলুন')}</span>
                        </a>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Edit Profile Form Popup (Inline) */}
      {isEditingProfile && (
        <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-4">
          <h3 className="font-extrabold text-sm text-slate-900 dark:text-slate-100">
            {t('Update Your Contact & Community Profile', 'আপনার যোগাযোগের তথ্য সম্পাদনা')}
          </h3>
          <div className="grid sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Phone</label>
              <input
                type="text"
                value={editPhone}
                onChange={e => setEditPhone(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Village</label>
              <input
                type="text"
                value={editVillage}
                onChange={e => setEditVillage(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Blood Group</label>
              <input
                type="text"
                value={editBlood}
                onChange={e => setEditBlood(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>
          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 text-xs mb-1">Personal Bio</label>
            <textarea
              rows={2}
              value={editBio}
              onChange={e => setEditBio(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs"
            />
          </div>
          <div className="flex justify-end gap-2">
            <button
              onClick={() => setIsEditingProfile(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
            >
              {t('Cancel', 'বাতিল')}
            </button>
            <button
              onClick={handleSaveProfile}
              className="px-5 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg"
            >
              {t('Save Changes', 'সংরক্ষণ করুন')}
            </button>
          </div>
        </div>
      )}

      {/* 2. Navigation Tabs */}
      <div className="border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {[
            { id: 'wall', labelEn: 'Youth Discussion Wall', labelBn: 'কমিউনিটি ফোরাম', icon: MessageSquare },
            { id: 'notices', labelEn: 'Notice Board & PDF Circulars', labelBn: 'অফিসিয়াল নোটিশ ও PDF', icon: FileText, count: news.length },
            { id: 'directory', labelEn: 'Member Directory & Blood Donors', labelBn: 'সদস্য তালিকা ও রক্তদাতা', icon: Users, count: members.length },
            { id: 'events', labelEn: 'My Events & RSVP', labelBn: 'আমার ইভেন্টসমূহ', icon: Calendar, count: events.length },
            { id: 'fund', labelEn: 'Community Fund Transparency', labelBn: 'কমিউনিটি ফান্ড হিসাব', icon: DollarSign },
          ].map(tab => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl whitespace-nowrap transition-all ${
                  active
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-emerald-800 dark:hover:text-emerald-400 hover:bg-emerald-50/60 dark:hover:bg-slate-800'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{t(tab.labelEn, tab.labelBn)}</span>
                {tab.count !== undefined && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    active ? 'bg-emerald-800 text-emerald-100' : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                  }`}>
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. Tab Contents */}

      {/* TAB A: Youth Discussion Wall */}
      {activeTab === 'wall' && (
        <div className="grid lg:grid-cols-12 gap-8 items-start">
          
          {/* Main Discussion Feed */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* Create Post Box */}
            <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200/90 dark:border-slate-800 shadow-xs space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 flex items-center justify-center font-bold text-sm">
                  {currentMember.name[0]}
                </div>
                <div>
                  <div className="font-bold text-sm text-slate-900 dark:text-slate-100">{currentMember.name}</div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">{currentMember.role} · {currentMember.village}</div>
                </div>
              </div>

              <form onSubmit={handlePostSubmit} className="space-y-3">
                <textarea
                  rows={3}
                  value={newPostText}
                  onChange={e => setNewPostText(e.target.value)}
                  placeholder={t(
                    'Share an idea, question, or update with community youth...',
                    'কমিউনিটি সদস্যদের সাথে কোনো প্রস্তাব, ভাবনা বা প্রশ্ন শেয়ার করুন...'
                  )}
                  className="w-full px-4 py-3 text-sm rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-transparent"
                />

                <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-500 dark:text-slate-400">{t('Topic:', 'বিষয়:')}</span>
                    <select
                      value={newPostCategory}
                      onChange={e => setNewPostCategory(e.target.value as any)}
                      className="text-xs font-medium bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-lg border-0 text-slate-700 dark:text-slate-300"
                    >
                      <option value="General">{t('General Thought', 'সাধারণ আলোচনা')}</option>
                      <option value="Project Idea">{t('Project Idea', 'উদ্যোগ প্রস্তাব')}</option>
                      <option value="Event Prep">{t('Event Prep', 'অনুষ্ঠানের প্রস্তুতি')}</option>
                      <option value="Question">{t('Question / Help', 'সহায়তা / প্রশ্ন')}</option>
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-xs"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{t('Post to Wall', 'পোস্ট করুন')}</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Discussions List */}
            <div className="space-y-4">
              {discussions.map(post => (
                <div
                  key={post.id}
                  className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-slate-800 text-emerald-800 dark:text-emerald-300 font-bold flex items-center justify-center text-sm border border-emerald-100 dark:border-slate-700">
                        {post.authorName[0]}
                      </div>
                      <div>
                        <div className="font-bold text-sm text-slate-900 dark:text-slate-100">{post.authorName}</div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400">{post.authorRole} · {post.date}</div>
                      </div>
                    </div>
                    <span className="text-[11px] font-bold px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 rounded-lg">
                      {post.category}
                    </span>
                  </div>

                  <p className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed">
                    {post.text}
                  </p>

                  <div className="flex items-center gap-4 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                    <button
                      onClick={() => likeDiscussionPost(post.id)}
                      className={`flex items-center gap-1.5 font-bold transition-colors ${
                        post.likedByMe ? 'text-emerald-700 dark:text-emerald-400' : 'text-slate-500 hover:text-emerald-700'
                      }`}
                    >
                      <ThumbsUp className={`w-4 h-4 ${post.likedByMe ? 'fill-emerald-700' : ''}`} />
                      <span>{post.likes} {t('Appreciate', 'পছন্দ')}</span>
                    </button>
                    <span className="text-slate-300 dark:text-slate-600">·</span>
                    <span className="text-slate-500 dark:text-slate-400">
                      {post.replies.length} {t('Replies', 'মন্তব্য')}
                    </span>
                  </div>

                  {/* Replies list */}
                  {post.replies.length > 0 && (
                    <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                      {post.replies.map(reply => (
                        <div key={reply.id} className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl space-y-1 text-xs">
                          <div className="flex items-center justify-between text-slate-600 dark:text-slate-400">
                            <span className="font-bold text-slate-900 dark:text-slate-100">{reply.author} <small className="text-slate-500 dark:text-slate-400 font-normal">({reply.role})</small></span>
                            <span className="text-[10px] text-slate-400">{reply.date}</span>
                          </div>
                          <p className="text-slate-700 dark:text-slate-300">{reply.text}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Add reply row */}
                  <div className="flex items-center gap-2 pt-2">
                    <input
                      type="text"
                      value={replyInputs[post.id] || ''}
                      onChange={e => setReplyInputs({ ...replyInputs, [post.id]: e.target.value })}
                      onKeyDown={e => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleReplySubmit(post.id);
                        }
                      }}
                      placeholder={t('Write a supportive reply...', 'একটি মন্তব্য লিখুন...')}
                      className="flex-1 px-4 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    />
                    <button
                      onClick={() => handleReplySubmit(post.id)}
                      className="px-3 py-2 bg-emerald-100 dark:bg-slate-800 hover:bg-emerald-200 text-emerald-900 dark:text-emerald-300 font-bold text-xs rounded-xl transition-colors"
                    >
                      {t('Reply', 'উত্তর')}
                    </button>
                  </div>
                </div>
              ))}
            </div>

          </div>

          {/* Right Column: Values & Emergency Blood Donors Quick Box */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Urgent Blood Network Box */}
            <div className="bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 rounded-3xl p-5 space-y-3 text-rose-950 dark:text-rose-200">
              <div className="flex items-center gap-2 font-bold text-sm text-rose-900 dark:text-rose-300">
                <Droplet className="w-4 h-4 fill-rose-600 text-rose-600" />
                <span>{t('Emergency Blood Network', 'জরুরি রক্তের নেটওয়ার্ক')}</span>
              </div>
              <p className="text-xs text-rose-800/90 dark:text-rose-300/90 leading-relaxed">
                {t(
                  'Salmikkhang members maintain a blood donor registry for Gaira & Jolchotro patients in Madhupur hospitals.',
                  'মধুপুরের যে কোনো জরুরি প্রয়োজনে আমাদের সদস্যদের রক্তের গ্রুপ ও ফোন নম্বর প্রস্তুত রাখা আছে।'
                )}
              </p>
              <button
                onClick={() => setActiveTab('directory')}
                className="w-full py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl transition-colors"
              >
                {t('Find Blood Donors by Group →', 'রক্তদাতাদের তালিকা দেখুন →')}
              </button>
            </div>

            {/* Community Values Card */}
            <div className="bg-emerald-900 dark:bg-slate-800 text-white rounded-3xl p-6 space-y-3">
              <div className="text-emerald-300 font-bold text-xs uppercase tracking-wider">
                {t('YOUTH CODE OF CONDUCT', 'সদস্য নীতিমালা')}
              </div>
              <h3 className="font-extrabold text-base text-white">
                {t('Our Shared Commitments', 'আমাদের অঙ্গীকার')}
              </h3>
              <ul className="space-y-2 text-xs text-emerald-100/90 dark:text-slate-300 leading-relaxed">
                <li className="flex items-start gap-2">
                  <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                  <span>Respect all community elders and encourage younger students.</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                  <span>Actively care for local trees and keep public spaces clean.</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                  <span>Honor and preserve Achik cultural heritage and songs.</span>
                </li>
              </ul>
            </div>

          </div>

        </div>
      )}

      {/* TAB B: Notice Board & PDF Circulars */}
      {activeTab === 'notices' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800">
            <div>
              <h2 className="text-xl font-extrabold text-slate-900 dark:text-slate-100">
                {t('Official Notice Board & Circulars', 'অফিসিয়াল নোটিশ ও পরিপত্র')}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                {t('Browse public bulletins and exclusive members-only council circulars.', 'সার্বজনীন ঘোষণা ও শুধুমাত্র সদস্যদের জন্য অভ্যন্তরীণ পরিপত্র।')}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* Audience Filter Pills */}
              <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-semibold">
                <button
                  onClick={() => setNoticeAudienceFilter('All')}
                  className={`px-2.5 py-1 rounded-lg transition-colors ${
                    noticeAudienceFilter === 'All'
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {t('All', 'সকল')}
                </button>
                <button
                  onClick={() => setNoticeAudienceFilter('members_only')}
                  className={`px-2.5 py-1 rounded-lg transition-colors flex items-center gap-1 ${
                    noticeAudienceFilter === 'members_only'
                      ? 'bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-200 font-bold shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <span>🔒</span>
                  <span>{t('Members Only', 'শুধুমাত্র সদস্য')}</span>
                </button>
                <button
                  onClick={() => setNoticeAudienceFilter('public')}
                  className={`px-2.5 py-1 rounded-lg transition-colors ${
                    noticeAudienceFilter === 'public'
                      ? 'bg-blue-100 dark:bg-blue-950 text-blue-900 dark:text-blue-200 font-bold shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {t('Public', 'সার্বজনীন')}
                </button>
              </div>

              {/* Search input */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  value={noticeSearch}
                  onChange={e => setNoticeSearch(e.target.value)}
                  placeholder={t('Search notices...', 'নোটিশ খুঁজুন...')}
                  className="pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>
            </div>
          </div>

          <div className="space-y-4">
            {filteredNotices.map(item => (
              <div
                key={item.id}
                className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200/90 dark:border-slate-800 shadow-xs space-y-4 hover:border-emerald-200 dark:hover:border-slate-700 transition-all"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold px-2.5 py-1 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 rounded-md">
                      {t(item.category, item.categoryBn)}
                    </span>
                    {item.visibility === 'members_only' ? (
                      <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-300 border border-amber-300 dark:border-amber-800 rounded-md flex items-center gap-1">
                        <span>🔒</span>
                        <span>{t('Members Only (Private)', 'শুধুমাত্র সদস্য (অভ্যন্তরীণ)')}</span>
                      </span>
                    ) : (
                      <span className="text-[10px] font-medium px-2 py-0.5 bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 rounded-md">
                        {t('Public Notice', 'সার্বজনীন')}
                      </span>
                    )}
                    <span className="text-xs text-slate-400">{item.date}</span>
                  </div>

                  {item.pdfAttachment && (
                    <span className="text-xs font-bold text-rose-600 dark:text-rose-400 flex items-center gap-1">
                      <FileText className="w-4 h-4" />
                      <span>{t('Official PDF Attached', 'অফিসিয়াল PDF সংযুক্ত')}</span>
                    </span>
                  )}
                </div>

                <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                  {t(item.title, item.titleBn)}
                </h3>

                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  {t(item.summary || item.content, item.summaryBn || item.contentBn)}
                </p>

                {/* PDF ATTACHMENT CARD */}
                {item.pdfAttachment && (
                  <div className="p-4 bg-rose-50/70 dark:bg-rose-950/40 rounded-2xl border border-rose-200 dark:border-rose-900 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-rose-100 dark:bg-rose-900 text-rose-700 dark:text-rose-300 flex items-center justify-center font-bold text-xs shrink-0">
                        PDF
                      </div>
                      <div>
                        <div className="font-bold text-xs text-slate-900 dark:text-slate-100">
                          {item.pdfAttachment.fileName}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400">
                          {item.pdfAttachment.fileSize} · {t('Official signed circular', 'কাউন্সিল স্বাক্ষরিত নোটিশ')}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <a
                        href={item.pdfAttachment.dataUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3.5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-xs transition-colors"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>{t('Open / View PDF', 'PDF দেখুন')}</span>
                      </a>
                      <a
                        href={item.pdfAttachment.dataUrl}
                        download={item.pdfAttachment.fileName}
                        className="px-3.5 py-2 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs rounded-xl border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 transition-colors"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>{t('Download', 'ডাউনলোড')}</span>
                      </a>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB C: Member Directory & Blood Donor Finder */}
      {activeTab === 'directory' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800">
            <div>
              <h2 className="text-xl font-extrabold text-slate-900 dark:text-slate-100">
                {t('Salmikkhang Member Directory', 'সালমিকখাং সদস্য ও রক্তদাতা তালিকা')}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                {t('Browse verified youth members and emergency blood volunteers.', 'যাচাইকৃত সক্রিয় সদস্য ও জরুরি রক্তদাতাদের তালিকা।')}
              </p>
            </div>

            {/* Filter controls */}
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  value={directorySearch}
                  onChange={e => setDirectorySearch(e.target.value)}
                  placeholder={t('Search name, village...', 'নাম বা এলাকা খুঁজুন...')}
                  className="pl-8 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              {/* Blood group selector */}
              <select
                value={bloodFilter}
                onChange={e => setBloodFilter(e.target.value)}
                className="px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300"
              >
                <option value="All">{t('All Blood Groups', 'সকল রক্তের গ্রুপ')}</option>
                {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map(b => (
                  <option key={b} value={b}>{b} Blood</option>
                ))}
              </select>

              {/* Village selector */}
              <select
                value={villageFilter}
                onChange={e => setVillageFilter(e.target.value)}
                className="px-3 py-2 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300"
              >
                <option value="All">{t('All Villages', 'সকল গ্রাম')}</option>
                <option value="Gaira">Gaira (গাইরা)</option>
                <option value="Jolchotro">Jolchotro (জলছত্র)</option>
                <option value="Madhupur">Madhupur (মধুপুর)</option>
              </select>
            </div>
          </div>

          {/* Members Card Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredMembers.map(member => (
              <div
                key={member.id}
                className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200/90 dark:border-slate-800 shadow-xs hover:border-emerald-300 hover:shadow-md transition-all space-y-4"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-extrabold flex items-center justify-center text-lg overflow-hidden shrink-0">
                      {member.avatar ? (
                        <img src={member.avatar} alt={member.name} className="w-full h-full object-cover" />
                      ) : (
                        member.name[0]
                      )}
                    </div>
                    <div>
                      <div className="font-bold text-sm text-slate-900 dark:text-slate-100 leading-tight">
                        {member.name}
                      </div>
                      <div className="text-xs text-emerald-700 dark:text-emerald-400 font-medium mt-0.5">
                        {member.role}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                        {member.memberNo}
                      </div>
                    </div>
                  </div>

                  {/* Blood Group Badge */}
                  <div className="px-2.5 py-1 rounded-lg bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-400 font-black text-xs flex items-center gap-1">
                    <Droplet className="w-3 h-3 fill-rose-600 text-rose-600" />
                    <span>{member.bloodGroup}</span>
                  </div>
                </div>

                <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300 pt-1">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    <span>{member.village}, Madhupur</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>{member.phone}</span>
                  </div>
                  <div className="flex items-center gap-2 truncate">
                    <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{member.email}</span>
                  </div>
                </div>

                {member.skills && member.skills.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 pt-2 border-t border-slate-100 dark:border-slate-800">
                    {member.skills.map((skill, i) => (
                      <span key={i} className="text-[10px] font-medium px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-md">
                        {skill}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB D: Events & Participation */}
      {activeTab === 'events' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200 dark:border-slate-800">
            <h2 className="text-xl font-extrabold text-slate-900 dark:text-slate-100">
              {t('Community Events & Your Participation', 'কমিউনিটি ইভেন্ট ও অংশগ্রহণ')}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {t('RSVP for upcoming drives or meetings. Members-only events are marked with a lock.', 'আসন্ন অনুষ্ঠানসমূহে অংশগ্রহণের নিশ্চয়তা দিন। সদস্যদের বিশেষ ইভেন্টগুলোতে অংশগ্রহণ করুন।')}
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {events.map(ev => {
              const isRsvpd = ev.rsvps.includes(currentMember.name);
              return (
                <div
                  key={ev.id}
                  className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs flex flex-col justify-between space-y-4"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold px-2.5 py-1 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 rounded-md">
                          {t(ev.category, ev.categoryBn)}
                        </span>
                        {ev.visibility === 'members_only' ? (
                          <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-300 border border-amber-300 dark:border-amber-800 rounded-md flex items-center gap-1">
                            <span>🔒</span>
                            <span>{t('Members Only', 'শুধুমাত্র সদস্য')}</span>
                          </span>
                        ) : (
                          <span className="text-[10px] font-medium px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-md">
                            {t('Public Event', 'সার্বজনীন')}
                          </span>
                        )}
                      </div>
                      <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                        {ev.date}
                      </span>
                    </div>

                    <h3 className="font-bold text-lg text-slate-900 dark:text-slate-100">
                      {t(ev.title, ev.titleBn)}
                    </h3>

                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                      {t(ev.description, ev.descriptionBn)}
                    </p>

                    <div className="space-y-1 text-xs text-slate-500 dark:text-slate-400 pt-1">
                      <div className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
                        <span>{t(ev.location, ev.locationBn)}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Users className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400" />
                        <span>{ev.rsvps.length} {t('members attending', 'সদস্য অংশ নিচ্ছেন')}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
                      {isRsvpd ? (
                        <span className="text-emerald-700 dark:text-emerald-400 font-bold flex items-center gap-1">
                          <Check className="w-3.5 h-3.5" />
                          <span>{t('You are attending', 'আপনি অংশ নিচ্ছেন')}</span>
                        </span>
                      ) : (
                        t('Not yet registered', 'এখনো নিশ্চিত করেননি')
                      )}
                    </span>
                    <button
                      onClick={() => toggleEventRsvp(ev.id, currentMember.name)}
                      className={`px-4 py-2 text-xs font-bold rounded-xl transition-colors ${
                        isRsvpd
                          ? 'bg-rose-50 dark:bg-rose-950 text-rose-700 dark:text-rose-400 hover:bg-rose-100'
                          : 'bg-emerald-700 hover:bg-emerald-800 text-white'
                      }`}
                    >
                      {isRsvpd ? t('Cancel Attendance', 'অংশগ্রহণ বাতিল') : t('Confirm RSVP', 'অংশগ্রহণ নিশ্চিত করুন')}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB E: Community Fund Transparency */}
      {activeTab === 'fund' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800">
            <div className="grid sm:grid-cols-3 gap-6">
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-100 dark:border-emerald-900">
                <div className="text-xs font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider">
                  {t('Current Fund Balance', 'বর্তমান তহবিল ব্যালেন্স')}
                </div>
                <div className="text-3xl font-extrabold text-emerald-950 dark:text-emerald-100 mt-1">
                  ৳ {funds.reduce((acc, f) => f.type === 'Inflow' ? acc + f.amount : acc - f.amount, 0).toLocaleString()}
                </div>
                <div className="text-[11px] text-emerald-700 dark:text-emerald-400 mt-1">
                  {t('Audited by Youth Council', 'যুব কাউন্সিল কর্তৃক নিরীক্ষিত')}
                </div>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-700">
                <div className="text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider">
                  {t('Total Inflows (Oct-Nov)', 'মোট জমা (অক্টো-নভে)')}
                </div>
                <div className="text-2xl font-bold text-slate-900 dark:text-slate-100 mt-1">
                  ৳ {funds.filter(f => f.type === 'Inflow').reduce((acc, f) => acc + f.amount, 0).toLocaleString()}
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                  {t('Member dues & well-wisher donations', 'সদস্য চাঁদা ও অনুদান')}
                </div>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-700">
                <div className="text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider">
                  {t('Community Expenses', 'উন্নয়নমূলক ব্যয়')}
                </div>
                <div className="text-2xl font-bold text-slate-900 dark:text-slate-100 mt-1">
                  ৳ {funds.filter(f => f.type === 'Outflow').reduce((acc, f) => acc + f.amount, 0).toLocaleString()}
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                  {t('Tree saplings, tutoring, sports kit', 'চারা ক্রয়, শিক্ষা সামগ্রী ও খেলাধুলা')}
                </div>
              </div>
            </div>
          </div>

          {/* Transactions Ledger */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
            <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <h3 className="font-extrabold text-slate-900 dark:text-slate-100 text-sm">
                {t('Transparent Transaction Ledger', 'স্বচ্ছ হিসাব বিবরণী')}
              </h3>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                {funds.length} {t('transactions recorded', 'টি লেনদেন')}
              </span>
            </div>
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {funds.map(f => (
                <div key={f.id} className="p-4 sm:px-6 flex items-center justify-between text-xs">
                  <div className="space-y-0.5">
                    <div className="font-bold text-sm text-slate-900 dark:text-slate-100">
                      {t(f.title, f.titleBn)}
                    </div>
                    <div className="text-slate-500 dark:text-slate-400">
                      {f.date} · {f.category} · {f.donorOrBeneficiary}
                    </div>
                  </div>
                  <div className={`font-black text-sm ${
                    f.type === 'Inflow' ? 'text-emerald-700 dark:text-emerald-400' : 'text-slate-700 dark:text-slate-300'
                  }`}>
                    {f.type === 'Inflow' ? '+' : '-'} ৳ {f.amount.toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
