import React, { useState } from 'react';
import { CommunityProvider, useCommunity } from './context/CommunityContext';
import { Header } from './components/Header';
import { PublicWebsite } from './components/PublicWebsite';
import { MemberPortal } from './components/MemberPortal';
import { AdminDashboard } from './components/AdminDashboard';
import { Modals } from './components/Modals';
import { Shield, Users, CheckCircle, Info, AlertTriangle } from 'lucide-react';

const MainApp: React.FC = () => {
  const {
    currentView,
    setCurrentView,
    toast,
    joinRequests,
    t
  } = useCommunity();

  const [searchOpen, setSearchOpen] = useState(false);
  const [selectedNewsId, setSelectedNewsId] = useState<string | null>(null);
  const [selectedGalleryItem, setSelectedGalleryItem] = useState<any | null>(null);

  const pendingRequests = joinRequests.filter(r => r.status === 'Pending').length;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 flex flex-col font-sans selection:bg-emerald-200 selection:text-emerald-900 transition-colors">
      
      {/* Toast Notification Notification Pill */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <div className={`px-4 py-3 rounded-2xl shadow-xl border flex items-center gap-2.5 text-xs font-semibold ${
            toast.type === 'warning'
              ? 'bg-amber-50 dark:bg-amber-950 border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200'
              : toast.type === 'info'
              ? 'bg-slate-900 dark:bg-slate-800 border-slate-700 text-white'
              : 'bg-emerald-900 dark:bg-emerald-800 border-emerald-700 dark:border-emerald-600 text-white'
          }`}>
            {toast.type === 'warning' ? (
              <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
            ) : toast.type === 'info' ? (
              <Info className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            )}
            <span>{toast.message}</span>
          </div>
        </div>
      )}

      {/* Main Top Header */}
      <Header onOpenSearch={() => setSearchOpen(true)} />

      {/* Main View Router */}
      <main className="flex-1">
        {currentView === 'website' && (
          <PublicWebsite
            onSelectNews={(id) => setSelectedNewsId(id)}
            onSelectGallery={(item) => setSelectedGalleryItem(item)}
          />
        )}

        {currentView === 'member' && <MemberPortal />}

        {currentView === 'admin' && <AdminDashboard />}
      </main>

      {/* Global Interactive Modals */}
      <Modals
        searchOpen={searchOpen}
        onCloseSearch={() => setSearchOpen(false)}
        selectedNewsId={selectedNewsId}
        onCloseNews={() => setSelectedNewsId(null)}
        selectedGalleryItem={selectedGalleryItem}
        onCloseGallery={() => setSelectedGalleryItem(null)}
      />

      {/* Floating View Switcher Bar for Quick Evaluation / Testing */}
      <div className="fixed bottom-4 left-4 z-40 hidden sm:flex items-center gap-1.5 p-1.5 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md rounded-2xl border border-emerald-200 dark:border-slate-800 shadow-xl text-xs font-semibold">
        <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider px-2">
          {t('Portal:', 'ভিউ:')}
        </span>
        <button
          onClick={() => setCurrentView('website')}
          className={`px-3 py-1.5 rounded-xl transition-all ${
            currentView === 'website'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-300 hover:text-emerald-800 dark:hover:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-slate-800'
          }`}
        >
          {t('Website', 'পাবলিক সাইট')}
        </button>
        <button
          onClick={() => setCurrentView('member')}
          className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 ${
            currentView === 'member'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-300 hover:text-emerald-800 dark:hover:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-slate-800'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>{t('Member Panel', 'সদস্য প্যানেল')}</span>
        </button>
        <button
          onClick={() => setCurrentView('admin')}
          className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 ${
            currentView === 'admin'
              ? 'bg-emerald-800 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-300 hover:text-emerald-800 dark:hover:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-slate-800'
          }`}
        >
          <Shield className="w-3.5 h-3.5" />
          <span>{t('Admin Panel', 'অ্যাডমিন')}</span>
          {pendingRequests > 0 && (
            <span className="px-1.5 py-0.2 bg-amber-500 text-white text-[10px] font-bold rounded">
              {pendingRequests}
            </span>
          )}
        </button>
      </div>

    </div>
  );
};

export default function App() {
  return (
    <CommunityProvider>
      <MainApp />
    </CommunityProvider>
  );
}
