export type Language = 'en' | 'bn';
export type Theme = 'light' | 'dark' | 'system';

export type Role = 
  | 'President' 
  | 'General Secretary' 
  | 'Advisor' 
  | 'Youth Coordinator' 
  | 'Executive Member' 
  | 'Volunteer' 
  | 'Member';

export interface Member {
  id: string;
  memberNo: string; // e.g. "SMK-2026-001"
  name: string;
  email: string;
  phone: string;
  password?: string; // Member portal login password
  role: Role;
  status: 'Active' | 'Inactive';
  village: string;
  bloodGroup: string; // "A+", "B+", "O+", "AB+", etc.
  skills: string[];
  interests: string[];
  joinDate: string;
  avatar?: string;
  bio?: string;
}

export interface JoinRequest {
  id: string;
  name: string;
  email: string;
  phone: string;
  village: string;
  bloodGroup: string;
  skills: string;
  interests: string;
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  date: string;
}

export interface CommunityEvent {
  id: string;
  title: string;
  titleBn: string;
  date: string;
  time: string;
  timeBn: string;
  location: string;
  locationBn: string;
  category: 'Meeting' | 'Environment' | 'Culture' | 'Sports' | 'Education';
  categoryBn: string;
  description: string;
  descriptionBn: string;
  image: string;
  status: 'Upcoming' | 'Past' | 'Planning';
  visibility: 'public' | 'members_only'; // public for all visitors, members_only for registered members
  rsvps: string[]; // array of member emails or names
}

export interface PdfAttachment {
  fileName: string;
  fileSize?: string;
  dataUrl: string;
}

export interface NewsItem {
  id: string;
  title: string;
  titleBn: string;
  category: 'Announcement' | 'Notice' | 'Education' | 'Environment' | 'Sports' | 'Community';
  categoryBn: string;
  date: string;
  summary: string;
  summaryBn: string;
  content: string;
  contentBn: string;
  image: string;
  tagColor: 'green' | 'blue' | 'purple' | 'amber';
  status: 'Published' | 'Draft';
  visibility?: 'public' | 'members_only'; // public for all visitors, members_only for registered members only
  pdfAttachment?: PdfAttachment;
}

export interface MemberNotification {
  id: string;
  title: string;
  titleBn: string;
  message: string;
  messageBn: string;
  date: string;
  type: 'notice' | 'event' | 'system';
  pdfAttachment?: PdfAttachment;
  read: boolean;
}

export interface Project {
  id: string;
  title: string;
  titleBn: string;
  category: string;
  categoryBn: string;
  status: 'Ongoing' | 'Planning' | 'Completed';
  statusBn: string;
  progress: number; // 0 - 100
  description: string;
  descriptionBn: string;
  image: string;
  volunteersNeeded: number;
  volunteersEnrolled: number;
}

export interface GalleryItem {
  id: string;
  title: string;
  titleBn: string;
  category: string;
  categoryBn: string;
  image: string;
  date: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  contact: string;
  message: string;
  date: string;
  status: 'Unread' | 'Read' | 'Replied';
}

export interface DiscussionPost {
  id: string;
  authorName: string;
  authorRole: string;
  authorAvatar?: string;
  date: string;
  text: string;
  category: 'General' | 'Project Idea' | 'Question' | 'Event Prep';
  likes: number;
  likedByMe?: boolean;
  replies: {
    id: string;
    author: string;
    role: string;
    text: string;
    date: string;
  }[];
}

export interface FundTransaction {
  id: string;
  date: string;
  type: 'Inflow' | 'Outflow';
  amount: number;
  title: string;
  titleBn: string;
  donorOrBeneficiary: string;
  category: 'Membership Dues' | 'Tree Saplings' | 'Sports Equipment' | 'Education Supplies' | 'Event Food & Tent';
}

export interface CommunitySettings {
  name: string;
  nameBn: string;
  village: string;
  address: string;
  phone: string;
  email: string;
  motto: string;
  mottoBn: string;
  about: string;
  aboutBn: string;
}
